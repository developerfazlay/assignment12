

  <?php 
  
  include 'includes/header.php';
  include 'includes/hero.php';
  

  ?>

  

  <main id="main">

  <?php
  
  include 'includes/our_values.php';
  include 'includes/features.php';
  include 'includes/pricing.php';
  include 'includes/faq.php';
  include 'includes/testimonial.php';      
  include 'includes/clients.php';      
  include 'includes/blog.php';      
  include 'includes/contact-main-page.php';      

  
  ?>
    

  </main><!-- End #main -->


  

  <?php include "includes/footer.php";?>

</body>

</html>